package test;

public class TestTestFire {

}
